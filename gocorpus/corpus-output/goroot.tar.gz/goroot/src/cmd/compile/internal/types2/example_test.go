package types2_test;import("bytes";"cmd/compile/internal/syntax";"cmd/compile/internal/types2";"fmt";"log";"regexp";"sort";"strings");func ExampleScope(){var files []*syntax.File;for _,file:=range []struct{name,input string}{{"main.go",`
package main
import "fmt"
func main() {
	freezing := FToC(-18)
	fmt.Println(freezing, Boiling) }
`},{"celsius.go",`
package main
import "fmt"
type Celsius float64
func (c Celsius) String() string { return fmt.Sprintf("%g°C", c) }
func FToC(f float64) Celsius { return Celsius(f - 32 / 9 * 5) }
const Boiling Celsius = 100
func Unused() { {}; {{ var x int; _ = x }} } // make sure empty block scopes get printed
`}}{f,err:=parseSrc(file.name,file.input);if err!=nil{log.Fatal(err)};files=append(files,f)};conf:=types2.Config{Importer:defaultImporter()};pkg,err:=conf.Check("temperature",files,nil);if err!=nil{log.Fatal(err)};var buf bytes.Buffer;pkg.Scope().WriteTo(&buf,0,true);rx:=regexp.MustCompile(` 0x[a-fA-F0-9]*`);fmt.Println(rx.ReplaceAllString(buf.String(),""))};func ExampleInfo(){const input=`
package fib

type S string

var a, b, c = len(b), S(c), "hello"

func fib(x int) int {
	if x < 2 {
		return x
	}
	return fib(x-1) - fib(x-2)
}`;f,err:=parseSrc("fib.go",input);if err!=nil{log.Fatal(err)};info:=types2.Info{Types:make(map[syntax.Expr]types2.TypeAndValue),Defs:make(map[*syntax.Name]types2.Object),Uses:make(map[*syntax.Name]types2.Object)};var conf types2.Config;pkg,err:=conf.Check("fib",[]*syntax.File{f},&info);if err!=nil{log.Fatal(err)};fmt.Printf("InitOrder: %v\n\n",info.InitOrder);fmt.Println("Defs and Uses of each named object:");usesByObj:=make(map[types2.Object][]string);for id,obj:=range info.Uses{posn:=id.Pos();lineCol:=fmt.Sprintf("%d:%d",posn.Line(),posn.Col());usesByObj[obj]=append(usesByObj[obj],lineCol)};var items []string;for obj,uses:=range usesByObj{sort.Strings(uses);item:=fmt.Sprintf("%s:\n  defined at %s\n  used at %s",types2.ObjectString(obj,types2.RelativeTo(pkg)),obj.Pos(),strings.Join(uses,", "));items=append(items,item)};sort.Strings(items);fmt.Println(strings.Join(items,"\n"));fmt.Println()};func mode(tv types2.TypeAndValue)string{switch{case tv.IsVoid():return "void";case tv.IsType():return "type";case tv.IsBuiltin():return "builtin";case tv.IsNil():return "nil";case tv.Assignable():if tv.Addressable(){return "var"};return "mapindex";case tv.IsValue():return "value";default:return "unknown"}}