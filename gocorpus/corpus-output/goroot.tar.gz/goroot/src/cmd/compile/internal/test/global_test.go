package test;import("bytes";"internal/testenv";"io/ioutil";"os";"os/exec";"path/filepath";"strings";"testing");func TestScanfRemoval(t *testing.T){testenv.MustHaveGoBuild(t);t.Parallel();dir,err:=ioutil.TempDir("","issue6853a-");if err!=nil{t.Fatalf("could not create directory: %v",err)};defer os.RemoveAll(dir);src:=filepath.Join(dir,"test.go");f,err:=os.Create(src);if err!=nil{t.Fatalf("could not create source file: %v",err)};f.Write([]byte(`
package main
import "fmt"
func main() {
	fmt.Println("hello world")
}
`));f.Close();dst:=filepath.Join(dir,"test");cmd:=exec.Command(testenv.GoToolPath(t),"build","-o",dst,src);out,err:=cmd.CombinedOutput();if err!=nil{t.Fatalf("could not build target: %v\n%s",err,out)};cmd=exec.Command(testenv.GoToolPath(t),"tool","nm",dst);out,err=cmd.CombinedOutput();if err!=nil{t.Fatalf("could not read target: %v",err)};if bytes.Contains(out,[]byte("scanInt")){t.Fatalf("scanf code not removed from helloworld")}};func TestDashS(t *testing.T){testenv.MustHaveGoBuild(t);t.Parallel();dir,err:=ioutil.TempDir("","issue14515-");if err!=nil{t.Fatalf("could not create directory: %v",err)};defer os.RemoveAll(dir);src:=filepath.Join(dir,"test.go");f,err:=os.Create(src);if err!=nil{t.Fatalf("could not create source file: %v",err)};f.Write([]byte(`
package main
import "fmt"
func main() {
	fmt.Println("hello world")
}
`));f.Close();cmd:=exec.Command(testenv.GoToolPath(t),"build","-gcflags","-S","-o",filepath.Join(dir,"test"),src);out,err:=cmd.CombinedOutput();if err!=nil{t.Fatalf("could not build target: %v\n%s",err,out)};patterns:=[]string{"\tTEXT\t","\tFUNCDATA\t","\tPCDATA\t"};outstr:=string(out);for _,p:=range patterns{if !strings.Contains(outstr,p){println(outstr);panic("can't find pattern "+p)}}}