package tenantcostserver;import("bytes";"context";"fmt";"math";"math/rand";"time";"github.com/cockroachdb/cockroach/pkg/base";"github.com/cockroachdb/cockroach/pkg/ccl/multitenantccl/tenantcostserver/tenanttokenbucket";"github.com/cockroachdb/cockroach/pkg/kv";"github.com/cockroachdb/cockroach/pkg/roachpb";"github.com/cockroachdb/cockroach/pkg/sql";"github.com/cockroachdb/cockroach/pkg/sql/sem/tree";"github.com/cockroachdb/cockroach/pkg/sql/sessiondata";"github.com/cockroachdb/cockroach/pkg/util/buildutil";"github.com/cockroachdb/cockroach/pkg/util/log";"github.com/cockroachdb/cockroach/pkg/util/protoutil";"github.com/cockroachdb/errors");type tenantState struct{Present bool;LastUpdate tree.DTimestamp;FirstInstance base.SQLInstanceID;Bucket tenanttokenbucket.State;Consumption roachpb.TenantConsumption};const defaultRefillRate=100;const defaultInitialRUs=10*1000*1000;const maxInstancesCleanup=10;func(ts *tenantState)update(now time.Time){if !ts.Present{*ts=tenantState{Present:true,LastUpdate:tree.DTimestamp{Time:now},FirstInstance:0,Bucket:tenanttokenbucket.State{RURefillRate:defaultRefillRate,RUCurrent:defaultInitialRUs}};return };delta:=now.Sub(ts.LastUpdate.Time);if delta>0{ts.Bucket.Update(delta);ts.LastUpdate.Time=now}};type instanceState struct{ID base.SQLInstanceID;Present bool;LastUpdate tree.DTimestamp;NextInstance base.SQLInstanceID;Lease tree.DBytes;Seq int64;Shares float64};type sysTableHelper struct{ctx context.Context;ex *sql.InternalExecutor;txn *kv.Txn;tenantID roachpb.TenantID};func makeSysTableHelper(ctx context.Context,ex *sql.InternalExecutor,txn *kv.Txn,tenantID roachpb.TenantID)sysTableHelper{return sysTableHelper{ctx:ctx,ex:ex,txn:txn,tenantID:tenantID}};func(h *sysTableHelper)readTenantState()(tenant tenantState,_ error){tenant,_,err:=h.readTenantAndInstanceState(0);return tenant,err};func(h *sysTableHelper)readTenantAndInstanceState(instanceID base.SQLInstanceID)(tenant tenantState,instance instanceState,_ error){instance.ID=instanceID;rows,err:=h.ex.QueryBufferedEx(h.ctx,"tenant-usage-select",h.txn,sessiondata.NodeUserSessionDataOverride,`SELECT
		  instance_id,               /* 0 */
			next_instance_id,          /* 1 */
			last_update,               /* 2 */
			ru_burst_limit,            /* 3 */
			ru_refill_rate,            /* 4 */
			ru_current,                /* 5 */
			current_share_sum,         /* 6 */
			total_consumption,         /* 7 */
			instance_lease,            /* 8 */
			instance_seq,              /* 9 */
			instance_shares            /* 10 */
		 FROM system.tenant_usage
		 WHERE tenant_id = $1 AND instance_id IN (0, $2)`,h.tenantID.ToUint64(),int64(instanceID));if err!=nil{return tenantState{},instanceState{},err};for _,r:=range rows{instanceID:=base.SQLInstanceID(tree.MustBeDInt(r[0]));if instanceID==0{tenant.Present=true;tenant.LastUpdate=tree.MustBeDTimestamp(r[2]);tenant.FirstInstance=base.SQLInstanceID(tree.MustBeDInt(r[1]));tenant.Bucket=tenanttokenbucket.State{RUBurstLimit:float64(tree.MustBeDFloat(r[3])),RURefillRate:float64(tree.MustBeDFloat(r[4])),RUCurrent:float64(tree.MustBeDFloat(r[5])),CurrentShareSum:float64(tree.MustBeDFloat(r[6]))};if consumption:=r[7];consumption!=tree.DNull{if err:=protoutil.Unmarshal([]byte(tree.MustBeDBytes(consumption)),&tenant.Consumption);err!=nil{return tenantState{},instanceState{},err}}}};return tenant,instance,nil};func(h *sysTableHelper)updateTenantState(tenant tenantState)error{consumption,err:=protoutil.Marshal(&tenant.Consumption);if err!=nil{return err};_,err=h.ex.ExecEx(h.ctx,"tenant-usage-upsert",h.txn,sessiondata.NodeUserSessionDataOverride,`UPSERT INTO system.tenant_usage(
		  tenant_id,
		  instance_id,
			next_instance_id,
			last_update,
			ru_burst_limit,
			ru_refill_rate,
			ru_current,
			current_share_sum,
			total_consumption,
			instance_lease,
			instance_seq,
			instance_shares
		 ) VALUES ($1, 0, $2, $3, $4, $5, $6, $7, $8, NULL, NULL, NULL)
		 `,h.tenantID.ToUint64(),int64(tenant.FirstInstance),&tenant.LastUpdate,tenant.Bucket.RUBurstLimit,tenant.Bucket.RURefillRate,tenant.Bucket.RUCurrent,tenant.Bucket.CurrentShareSum,tree.NewDBytes(tree.DBytes(consumption)));return err};func(h *sysTableHelper)updateTenantAndInstanceState(tenant tenantState,instance instanceState)error{consumption,err:=protoutil.Marshal(&tenant.Consumption);if err!=nil{return err};_,err=h.ex.ExecEx(h.ctx,"tenant-usage-insert",h.txn,sessiondata.NodeUserSessionDataOverride,`UPSERT INTO system.tenant_usage(
		  tenant_id,
		  instance_id,
			next_instance_id,
			last_update,
			ru_burst_limit,
			ru_refill_rate,
			ru_current,
			current_share_sum,
			total_consumption,
			instance_lease,
			instance_seq,
			instance_shares
		 ) VALUES
		   ($1, 0,  $2,  $3,  $4,   $5,   $6,   $7,   $8,   NULL, NULL, NULL),
			 ($1, $9, $10, $11, NULL, NULL, NULL, NULL, NULL, $12,  $13,  $14)
		 `,h.tenantID.ToUint64(),int64(tenant.FirstInstance),&tenant.LastUpdate,tenant.Bucket.RUBurstLimit,tenant.Bucket.RURefillRate,tenant.Bucket.RUCurrent,tenant.Bucket.CurrentShareSum,tree.NewDBytes(tree.DBytes(consumption)),int64(instance.ID),int64(instance.NextInstance),&instance.LastUpdate,&instance.Lease,instance.Seq,instance.Shares);return err};func(h *sysTableHelper)accomodateNewInstance(tenant *tenantState,instance *instanceState)error{if tenant.FirstInstance==0||tenant.FirstInstance>instance.ID{instance.NextInstance=tenant.FirstInstance;tenant.FirstInstance=instance.ID;return nil};row,err:=h.ex.QueryRowEx(h.ctx,"find-prev-id",h.txn,sessiondata.NodeUserSessionDataOverride,`SELECT
		  instance_id,               /* 0 */
			next_instance_id,          /* 1 */
			last_update,               /* 2 */
			instance_lease,            /* 3 */
			instance_seq,              /* 4 */
			instance_shares            /* 5 */
		 FROM system.tenant_usage
		 WHERE tenant_id = $1 AND instance_id > 0 AND instance_id < $2
		 ORDER BY instance_id DESC
		 LIMIT 1`,h.tenantID.ToUint64(),int64(instance.ID));if err!=nil{return err};if row==nil{return errors.Errorf("could not find row for previous instance")};prevInstanceID:=base.SQLInstanceID(tree.MustBeDInt(row[0]));instance.NextInstance=base.SQLInstanceID(tree.MustBeDInt(row[1]));prevInstanceLastUpdate:=row[2];prevInstanceLease:=row[3];prevInstanceSeq:=row[4];prevInstanceShares:=row[5];_,err=h.ex.ExecEx(h.ctx,"update-next-id",h.txn,sessiondata.NodeUserSessionDataOverride,`UPSERT INTO system.tenant_usage(
		  tenant_id,
		  instance_id,
			next_instance_id,
			last_update,
			ru_burst_limit,
			ru_refill_rate,
			ru_current,
			current_share_sum,
			total_consumption,
			instance_lease,
			instance_seq,
			instance_shares
		 ) VALUES ($1, $2, $3, $4, NULL, NULL, NULL, NULL, NULL, $5, $6, $7)
		`,h.tenantID.ToUint64(),int64(prevInstanceID),int64(instance.ID),prevInstanceLastUpdate,prevInstanceLease,prevInstanceSeq,prevInstanceShares);return err};func(h *sysTableHelper)maybeCleanupStaleInstance(cutoff time.Time,instanceID base.SQLInstanceID)(deleted bool,nextInstance base.SQLInstanceID,_ error){ts:=tree.MustMakeDTimestamp(cutoff,time.Microsecond);row,err:=h.ex.QueryRowEx(h.ctx,"tenant-usage-delete",h.txn,sessiondata.NodeUserSessionDataOverride,`DELETE FROM system.tenant_usage
		 WHERE tenant_id = $1 AND instance_id = $2 AND last_update < $3
		 RETURNING next_instance_id`,h.tenantID.ToUint64(),int32(instanceID),ts);if err!=nil{return false,-1,err};if row==nil{log.VEventf(h.ctx,1,"tenant %s instance %d not stale",h.tenantID,instanceID);return false,-1,nil};nextInstance=base.SQLInstanceID(tree.MustBeDInt(row[0]));log.VEventf(h.ctx,1,"cleaned up tenant %s instance %d",h.tenantID,instanceID);return true,nextInstance,nil};func(h *sysTableHelper)maybeCleanupStaleInstances(cutoff time.Time,startID,endID base.SQLInstanceID)(nextInstance base.SQLInstanceID,_ error){log.VEventf(h.ctx,1,"checking stale instances (tenant=%s startID=%d endID=%d)",h.tenantID,startID,endID);id:=startID;for n:=0;n<maxInstancesCleanup;n++{deleted,nextInstance,err:=h.maybeCleanupStaleInstance(cutoff,id);if err!=nil{return -1,err};if !deleted{break};id=nextInstance;if id==0||(endID!=-1&&id>=endID){break}};return id,nil};func(h *sysTableHelper)maybeCheckInvariants()error{if buildutil.CrdbTestBuild&&rand.Intn(10)==0{return h.checkInvariants()};return nil};func(h *sysTableHelper)checkInvariants()error{rows,err:=h.ex.QueryBufferedEx(h.ctx,"tenant-usage-select",h.txn,sessiondata.NodeUserSessionDataOverride,`SELECT
		  instance_id,               /* 0 */
			next_instance_id,          /* 1 */
			last_update,               /* 2 */
			ru_burst_limit,            /* 3 */
			ru_refill_rate,            /* 4 */
			ru_current,                /* 5 */
			current_share_sum,         /* 6 */
			total_consumption,         /* 7 */
			instance_lease,            /* 8 */
			instance_seq,              /* 9 */
			instance_shares            /* 10 */
		 FROM system.tenant_usage
		 WHERE tenant_id = $1
		 ORDER BY instance_id`,h.tenantID.ToUint64());if err!=nil{if h.ctx.Err()==nil{log.Warningf(h.ctx,"checkInvariants query failed: %v",err)};return nil};if len(rows)==0{return nil};instanceIDs:=make([]base.SQLInstanceID,len(rows));for i:=range rows{instanceIDs[i]=base.SQLInstanceID(tree.MustBeDInt(rows[i][0]));if i>0&&instanceIDs[i-1]>=instanceIDs[i]{return errors.New("instances out of order")}};if instanceIDs[0]!=0{return errors.New("instance 0 row missing")};for i:=range rows{var nullFirst,nullLast int;if i==0{nullFirst,nullLast=8,10};for j:=range rows[i]{isNull:=(rows[i][j]==tree.DNull);expNull:=(j>=nullFirst&&j<=nullLast);if expNull!=isNull{if !expNull{return errors.Errorf("expected NULL column %d",j)};if i!=7{return errors.Errorf("expected non-NULL column %d",j)}}}};for i:=range rows{expNextInstanceID:=base.SQLInstanceID(0);if i+1<len(rows){expNextInstanceID=instanceIDs[i+1]};nextInstanceID:=base.SQLInstanceID(tree.MustBeDInt(rows[i][1]));if expNextInstanceID!=nextInstanceID{return errors.Errorf("expected next instance %d, have %d",expNextInstanceID,nextInstanceID)}};sharesSum:=float64(tree.MustBeDFloat(rows[0][6]));var expSharesSum float64;for _,r:=range rows[1:]{expSharesSum+=float64(tree.MustBeDFloat(r[10]))};a,b:=sharesSum,expSharesSum;if a>b{a,b=b,a};const ulpTolerance=1000;if math.Float64bits(a)+ulpTolerance<=math.Float64bits(b){return errors.Errorf("expected shares sum %g, have %g",expSharesSum,sharesSum)};return nil};func InspectTenantMetadata(ctx context.Context,ex *sql.InternalExecutor,txn *kv.Txn,tenantID roachpb.TenantID,timeFormat string)(string,error){h:=makeSysTableHelper(ctx,ex,txn,tenantID);tenant,err:=h.readTenantState();if err!=nil{return "",err};if !tenant.Present{return "empty state",nil};var buf bytes.Buffer;fmt.Fprintf(&buf,"Bucket state: ru-burst-limit=%g  ru-refill-rate=%g  ru-current=%.12g  current-share-sum=%.12g\n",tenant.Bucket.RUBurstLimit,tenant.Bucket.RURefillRate,tenant.Bucket.RUCurrent,tenant.Bucket.CurrentShareSum);fmt.Fprintf(&buf,"Consumption: ru=%.12g  reads=%d req/%d bytes  writes=%d req/%d bytes  pod-cpu-usage: %g secs  pgwire-egress=%d bytes\n",tenant.Consumption.RU,tenant.Consumption.ReadRequests,tenant.Consumption.ReadBytes,tenant.Consumption.WriteRequests,tenant.Consumption.WriteBytes,tenant.Consumption.SQLPodsCPUSeconds,tenant.Consumption.PGWireEgressBytes);fmt.Fprintf(&buf,"Last update: %s\n",tenant.LastUpdate.Time.Format(timeFormat));fmt.Fprintf(&buf,"First active instance: %d\n",tenant.FirstInstance);rows,err:=ex.QueryBufferedEx(ctx,"inspect-tenant-state",txn,sessiondata.NodeUserSessionDataOverride,`SELECT
		  instance_id,               /* 0 */
			next_instance_id,          /* 1 */
			last_update,               /* 2 */
			instance_lease,            /* 3 */
			instance_seq,              /* 4 */
			instance_shares            /* 5 */
		 FROM system.tenant_usage
		 WHERE tenant_id = $1 AND instance_id > 0
		 ORDER BY instance_id`,tenantID.ToUint64());if err!=nil{return "",err};for _,r:=range rows{fmt.Fprintf(&buf,"  Instance %s:  lease=%q  seq=%s  shares=%s  next-instance=%s  last-update=%s\n",r[0],tree.MustBeDBytes(r[3]),r[4],r[5],r[1],tree.MustBeDTimestamp(r[2]).Time.Format(timeFormat))};return buf.String(),nil}