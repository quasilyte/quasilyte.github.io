package rttanalysis;import "testing";func BenchmarkVirtualTableQueries(b *testing.B){reg.Run(b)};func init(){reg.Register("VirtualTableQueries",[]RoundTripBenchTestCase{{Name:"select crdb_internal.tables with 1 fk",Setup:`
CREATE TABLE t1 (i INT PRIMARY KEY);
CREATE TABLE t2 (i INT PRIMARY KEY, j INT REFERENCES t1(i));
`,Stmt:`SELECT * FROM "".crdb_internal.tables`},{Name:"select crdb_internal.invalid_objects with 1 fk",Setup:`
CREATE TABLE t1 (i INT PRIMARY KEY);
CREATE TABLE t2 (i INT PRIMARY KEY, j INT REFERENCES t1(i));
`,Stmt:`SELECT * FROM "".crdb_internal.invalid_objects`}})}