package main;import("bufio";"bytes";"github.com/stretchr/testify/assert";"testing");func TestFetchYaml(t *testing.T){sourceYaml:=` # See the OWNERS docs at https://go.k8s.io/owners
approvers:
- dep-approvers
- thockin         # Network
- liggitt

labels:
- sig/architecture
`;outputYaml:=`# See the OWNERS docs at https://go.k8s.io/owners
approvers:
  - dep-approvers
  - thockin # Network
  - liggitt
labels:
  - sig/architecture
`;node,_:=fetchYaml([]byte(sourceYaml));var output bytes.Buffer;indent:=2;writer:=bufio.NewWriter(&output);_=streamYaml(writer,&indent,node);_=writer.Flush();assert.Equal(t,outputYaml,string(output.Bytes()),"yaml was not formatted correctly")}