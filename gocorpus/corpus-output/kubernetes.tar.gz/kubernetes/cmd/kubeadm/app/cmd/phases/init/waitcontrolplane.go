package phases;import("fmt";"io";"text/template";"time";"github.com/lithammer/dedent";"github.com/pkg/errors";clientset"k8s.io/client-go/kubernetes";"k8s.io/klog/v2";"k8s.io/kubernetes/cmd/kubeadm/app/cmd/phases/workflow";kubeadmconstants"k8s.io/kubernetes/cmd/kubeadm/app/constants";"k8s.io/kubernetes/cmd/kubeadm/app/util/apiclient";dryrunutil"k8s.io/kubernetes/cmd/kubeadm/app/util/dryrun");var(kubeletFailTempl=template.Must(template.New("init").Parse(dedent.Dedent(`
	Unfortunately, an error has occurred:
		{{ .Error }}

	This error is likely caused by:
		- The kubelet is not running
		- The kubelet is unhealthy due to a misconfiguration of the node in some way (required cgroups disabled)

	If you are on a systemd-powered system, you can try to troubleshoot the error with the following commands:
		- 'systemctl status kubelet'
		- 'journalctl -xeu kubelet'

	Additionally, a control plane component may have crashed or exited when started by the container runtime.
	To troubleshoot, list all containers using your preferred container runtimes CLI.
{{ if .IsDocker }}
	Here is one example how you may list all Kubernetes containers running in docker:
		- 'docker ps -a | grep kube | grep -v pause'
		Once you have found the failing container, you can inspect its logs with:
		- 'docker logs CONTAINERID'
{{ else }}
	Here is one example how you may list all Kubernetes containers running in cri-o/containerd using crictl:
		- 'crictl --runtime-endpoint {{ .Socket }} ps -a | grep kube | grep -v pause'
		Once you have found the failing container, you can inspect its logs with:
		- 'crictl --runtime-endpoint {{ .Socket }} logs CONTAINERID'
{{ end }}
	`))));func NewWaitControlPlanePhase()workflow.Phase{phase:=workflow.Phase{Name:"wait-control-plane",Run:runWaitControlPlanePhase,Hidden:true};return phase};func runWaitControlPlanePhase(c workflow.RunData)error{data,ok:=c.(InitData);if !ok{return errors.New("wait-control-plane phase invoked with an invalid data struct")};if data.DryRun(){if err:=dryrunutil.PrintFilesIfDryRunning(true,data.ManifestDir(),data.OutputWriter());err!=nil{return errors.Wrap(err,"error printing files on dryrun")}};klog.V(1).Infoln("[wait-control-plane] Waiting for the API server to be healthy");client,err:=data.Client();if err!=nil{return errors.Wrap(err,"cannot obtain client")};timeout:=data.Cfg().ClusterConfiguration.APIServer.TimeoutForControlPlane.Duration;waiter,err:=newControlPlaneWaiter(data.DryRun(),timeout,client,data.OutputWriter());if err!=nil{return errors.Wrap(err,"error creating waiter")};fmt.Printf("[wait-control-plane] Waiting for the kubelet to boot up the control plane as static Pods from directory %q. This can take up to %v\n",data.ManifestDir(),timeout);if err:=waiter.WaitForKubeletAndFunc(waiter.WaitForAPI);err!=nil{context:=struct{Error string;Socket string;IsDocker bool}{Error:fmt.Sprintf("%v",err),Socket:data.Cfg().NodeRegistration.CRISocket,IsDocker:data.Cfg().NodeRegistration.CRISocket==kubeadmconstants.DefaultDockerCRISocket};kubeletFailTempl.Execute(data.OutputWriter(),context);return errors.New("couldn't initialize a Kubernetes cluster")};return nil};func newControlPlaneWaiter(dryRun bool,timeout time.Duration,client clientset.Interface,out io.Writer)(apiclient.Waiter,error){if dryRun{return dryrunutil.NewWaiter(),nil};return apiclient.NewKubeWaiter(client,timeout,out),nil}