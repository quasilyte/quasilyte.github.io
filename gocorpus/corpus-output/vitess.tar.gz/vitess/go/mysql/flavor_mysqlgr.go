package mysql;import("errors";"fmt";"math";"vitess.io/vitess/go/vt/proto/vtrpc";"vitess.io/vitess/go/vt/vterrors";"vitess.io/vitess/go/sqltypes");const GRFlavorID="MysqlGR";var ErrNoGroupStatus=errors.New("no group status");type mysqlGRFlavor struct{mysqlFlavor};func newMysqlGRFlavor()flavor{return &mysqlGRFlavor{}};func(mysqlGRFlavor)startReplicationCommand()string{return ""};func(mysqlGRFlavor)restartReplicationCommands()[]string{return []string{}};func(mysqlGRFlavor)startReplicationUntilAfter(pos Position)string{return ""};func(mysqlGRFlavor)stopReplicationCommand()string{return ""};func(mysqlGRFlavor)stopIOThreadCommand()string{return ""};func(mysqlGRFlavor)resetReplicationCommands(c *Conn)[]string{return []string{}};func(mysqlGRFlavor)setReplicationPositionCommands(pos Position)[]string{return []string{}};func(mysqlGRFlavor)status(c *Conn)(ReplicationStatus,error){res:=ReplicationStatus{};query:=`SELECT
		MEMBER_HOST,
		MEMBER_PORT
	FROM
		performance_schema.replication_group_members
	WHERE
		MEMBER_ROLE='PRIMARY' AND MEMBER_STATE='ONLINE'`;err:=fetchStatusForGroupReplication(c,query,func(values []sqltypes.Value)error{parsePrimaryGroupMember(&res,values);return nil});if err!=nil{return ReplicationStatus{},err};query=`SELECT
		MEMBER_STATE
	FROM
		performance_schema.replication_group_members
	WHERE
		MEMBER_HOST=convert(@@hostname using ascii) AND MEMBER_PORT=@@port`;var chanel string;err=fetchStatusForGroupReplication(c,query,func(values []sqltypes.Value)error{state:=values[0].ToString();if state=="ONLINE"{chanel="group_replication_applier"}else if state=="RECOVERING"{chanel="group_replication_recovery"}else{res.ReplicationLagSeconds=math.MaxUint32};return nil});if err!=nil{return ReplicationStatus{},err};if chanel==""{return res,nil};query=fmt.Sprintf(`SELECT SERVICE_STATE
		FROM performance_schema.replication_connection_status
		WHERE CHANNEL_NAME='%s'`,chanel);var ioThreadRunning bool;err=fetchStatusForGroupReplication(c,query,func(values []sqltypes.Value)error{ioThreadRunning=values[0].ToString()=="ON";return nil});if err!=nil{return ReplicationStatus{},err};res.IOThreadRunning=ioThreadRunning;var sqlThreadRunning bool;query=fmt.Sprintf(`SELECT SERVICE_STATE
		FROM performance_schema.replication_applier_status_by_coordinator
		WHERE CHANNEL_NAME='%s'`,chanel);err=fetchStatusForGroupReplication(c,query,func(values []sqltypes.Value)error{sqlThreadRunning=values[0].ToString()=="ON";return nil});if err!=nil{return ReplicationStatus{},err};res.SQLThreadRunning=sqlThreadRunning;query=fmt.Sprintf(`SELECT
		TIMESTAMPDIFF(SECOND, LAST_PROCESSED_TRANSACTION_ORIGINAL_COMMIT_TIMESTAMP, LAST_PROCESSED_TRANSACTION_END_BUFFER_TIMESTAMP)
	FROM
		performance_schema.replication_applier_status_by_coordinator
	WHERE
		CHANNEL_NAME='%s'`,chanel);err=fetchStatusForGroupReplication(c,query,func(values []sqltypes.Value)error{parseReplicationApplierLag(&res,values);return nil});if err!=nil{return ReplicationStatus{},err};return res,nil};func parsePrimaryGroupMember(res *ReplicationStatus,row []sqltypes.Value){res.SourceHost=row[0].ToString();memberPort,_:=row[1].ToInt64();res.SourcePort=int(memberPort)};func parseReplicationApplierLag(res *ReplicationStatus,row []sqltypes.Value){lagSec,err:=row[0].ToInt64();if err==nil{res.ReplicationLagSeconds=uint(lagSec)}};func fetchStatusForGroupReplication(c *Conn,query string,onResult func([]sqltypes.Value)error)error{qr,err:=c.ExecuteFetch(query,100,true);if err!=nil{return err};if len(qr.Rows)==0{return ErrNoGroupStatus};if len(qr.Rows)>1{return vterrors.Errorf(vtrpc.Code_INTERNAL,"unexpected results for %v: %v",query,qr.Rows)};return onResult(qr.Rows[0])};func(mysqlGRFlavor)primaryStatus(c *Conn)(PrimaryStatus,error){return mysqlFlavor{}.primaryStatus(c)};func(mysqlGRFlavor)baseShowTablesWithSizes()string{return TablesWithSize80};func init(){flavors[GRFlavorID]=newMysqlGRFlavor}